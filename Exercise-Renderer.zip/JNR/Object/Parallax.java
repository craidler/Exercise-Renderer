package JNR.Object;

import JNR.Interface.Translatable;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

import java.util.ArrayList;

public class Parallax extends ArrayList<Layer> implements Translatable {
    private double f = 2;

    public static Parallax withPane(Pane pane) {
        Image image = new Image("JNR/Image/Gfeller.gif");
        Parallax parallax = new Parallax();

        parallax.add(new Layer(new ImageView(image)));
        parallax.add(new Layer(new ImageView(image)));
        parallax.add(new Layer(new ImageView(image)));

        pane.getChildren().addAll(parallax);

        return parallax;
    }

    public void translate(double x, double y) {
        for (int i = 0; i < size(); i++) {
            get(i).translate(x * (i + 1) * f, y * (i + 1) * f);
        }
    }
}
