package JNR.Object;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Layer extends Group {
    private double h;
    private double w;

    public Layer(ImageView view) {
        super(view);

        h = view.getImage().getHeight();
        w = view.getImage().getWidth();
    }

    public void translate(double x, double y) {
        System.out.println("translating Layer");

        double xc = getTranslateX();
        double yc = getTranslateY();
        double xn = xc + x;
        double yn = yc + y;

        try {
            if (xn > 0) {
                Image image = ((ImageView) getChildren().get(0)).getImage();
                ImageView view = new ImageView(image);
                view.setTranslateX(xn - image.getWidth());
                getChildren().add(view);
            }
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }

        setTranslateX(xn);
        setTranslateY(yn);
    }
}
