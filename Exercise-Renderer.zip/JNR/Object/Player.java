package JNR.Object;

import javafx.scene.image.Image;
import javafx.scene.layout.Pane;

public class Player extends Object {
    private static Image[] images = {
        new Image("JNR/Image/Issue.gif"),
    };

    public static Player with(Pane pane, double x, double y) {
        Player player = new Player();

        player.setImage(images[0]);
        player.translate(x, y);
        player.hide();

        pane.getChildren().add(player);


        return player;
    }

    public void spawn(double x, double y) {
        relocate(x, y);
        show();
    }
}
