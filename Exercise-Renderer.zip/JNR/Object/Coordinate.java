package JNR.Object;

public class Coordinate {
    double[] p = {0, 0};

    public double addX(double x) {
        return p[0] += x;
    }

    public double addY(double y) {
        return p[1] += y;
    }

    public double getX() {
        return p[0];
    }

    public double getY() {
        return p[1];
    }
}
