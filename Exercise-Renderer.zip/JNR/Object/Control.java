package JNR.Object;

import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.util.HashMap;

public class Control extends HashMap<KeyCode, Boolean> {
    public static Control withScene(Scene scene) {
        Control control = new Control();

        scene.addEventHandler(KeyEvent.KEY_PRESSED, event -> control.put(event.getCode(), true));
        scene.addEventHandler(KeyEvent.KEY_RELEASED, event -> control.put(event.getCode(), false));

        return control;
    }

    public boolean isPressed(KeyCode code) {
        return getOrDefault(code, false);
    }
}
