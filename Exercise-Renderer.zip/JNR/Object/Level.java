package JNR.Object;

import JNR.Interface.Translatable;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Level extends Group implements Runnable, Translatable {
    private ScheduledExecutorService s;
    private Control c;
    private int i = 0;


    public Level(ScheduledExecutorService service, Control control) {
        s = service;
        c = control;
    }

    public void run() {
        if (c.isPressed(KeyCode.LEFT)) translate(1, 0);
        if (c.isPressed(KeyCode.RIGHT)) translate(-1, 0);

        render();
    }

    public Level spawn(Pane pane) {
        getChildren().add(new ImageView(new Image("JNR/Image/Issue.gif")));
        pane.getChildren().add(this);
        s.scheduleAtFixedRate(this, 0, 1000 / 30, TimeUnit.MILLISECONDS);
        return this;
    }

    private void render() {
    }

    public void translate(double x, double y) {
        setTranslateX(getTranslateX() + x);
        setTranslateY(getTranslateY() + y);
    }
}
