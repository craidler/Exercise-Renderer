package JNR.Object;

import JNR.Interface.Translatable;
import javafx.scene.image.ImageView;

public class Object extends ImageView implements Translatable {


    public double addX(double x) {
        setX(getX() + x);

        return getX();
    }

    public double addY(double y) {
        setY(getY() + y);

        return getY();
    }

    public void hide() {
        setOpacity(0);
    }

    public void show() {
        setOpacity(1);
    }

    public void translate(double x, double y) {
        addX(x);
        addY(y);
    }
}
