package JNR.Task;

import JNR.Object.Level;
import JNR.Object.Parallax;
import JNR.Object.Player;

public class Render extends Thread {
    public static Render create(Parallax parallax, Level level, Player player) {
        Render render = new Render();

        return render;
    }

    public void run() {
        System.out.println(getId() + " " + getName());
    }
}
