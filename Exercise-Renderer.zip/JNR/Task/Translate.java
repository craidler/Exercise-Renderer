package JNR.Task;

import JNR.Interface.Translatable;
import JNR.Object.Control;
import javafx.scene.input.KeyCode;

public class Translate implements Runnable {
    private Translatable t;
    private Control c;

    public static Translate with(Control control, Translatable translatable) {
        Translate translate = new Translate();

        translate.c = control;
        translate.t = translatable;

        return translate;
    }

    public void run() {
        if (c.isPressed(KeyCode.LEFT)) t.translate(-1, 0);
        if (c.isPressed(KeyCode.RIGHT)) t.translate(1, 0);
    }
}
