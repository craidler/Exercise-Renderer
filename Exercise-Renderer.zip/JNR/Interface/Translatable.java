package JNR.Interface;

public interface Translatable {
    void translate(double x, double y);
}
