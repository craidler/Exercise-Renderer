package JNR.Interface;

public interface Renderer {
    void render();
}
