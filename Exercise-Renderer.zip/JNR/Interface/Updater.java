package JNR.Interface;

public interface Updater {
    void update();
}
