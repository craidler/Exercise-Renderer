package Interface;

import JNR.Renderer;

public interface Renderable {
    void render(Renderer r);
}
