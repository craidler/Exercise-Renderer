package Interface;

public interface Locatable {
    int getX();
    int getY();
    void relocate(int x, int y);
}
