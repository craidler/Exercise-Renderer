package Interface;

public interface Updatable {
    void update();
}
