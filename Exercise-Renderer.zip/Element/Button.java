package Element;

import Graphic.Rectangle;
import Interface.Locatable;
import Interface.Renderable;
import Interface.Updatable;
import JNR.Input;
import JNR.Renderer;

public class Button implements Locatable, Renderable, Updatable {
    private Rectangle bg, fg, render;
    private Input input = Input.instance;
    private Text label;
    private int x, y, w, h;

    public static Button create(int x, int y, int width, int height, String text) {
        Button button = new Button();

        button.x = x;
        button.y = y;
        button.w = width;
        button.h = height;
        button.bg = new Rectangle(x, y, width, height, 0xffbbbbbb, 0xff333333);
        button.fg = new Rectangle(x, y, width, height, 0xffbbbbbb, 0xff444444);
        button.label = new Text(x, y, text);
        button.label.relocate(x + (int) ((width - button.label.getW()) * .5), y + (int) ((height - button.label.getH()) * .5));
        button.render = button.bg;

        return button;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void relocate(int x, int y) {
        bg.relocate(x, y);
        fg.relocate(x, y);
        this.x = x;
        this.y = y;
    }

    public void render(Renderer r) {
        render.render(r);
        label.render(r);
    }

    public void update() {
        if (input.getMouseX() > x && input.getMouseX() <= x + w + 2 && input.getMouseY() > y && input.getMouseY() <= y + h + 2) {
            render = input.isButton(1) ? fg : bg;
        }
    }
}
