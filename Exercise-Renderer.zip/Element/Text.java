package Element;

import Graphic.Font;
import Interface.Locatable;
import Interface.Renderable;
import JNR.Renderer;

public class Text implements Locatable, Renderable {
    private String t;
    private int c = 0xffffffff, x, y, w = 0, h = 5;

    public Text(int x, int y, String text, int color) {
        this.c = color;
        this.x = x;
        this.y = y;
        this.t = text.toUpperCase();

        calc();
    }

    public Text(int x, int y, String text) {
        this.x = x;
        this.y = y;
        this.t = text.toUpperCase();

        calc();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getW() {
        return w;
    }

    public int getH() {
        return h;
    }

    public void relocate(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void render(Renderer r) {
        r.drawText(t, x, y, c);
    }

    private void calc() {
        Font f = Font.STANDARD;

        for (int i = 0; i < t.length(); i++) {
            w += f.getWidths()[t.codePointAt(i) - 32];
        }
    }
}
